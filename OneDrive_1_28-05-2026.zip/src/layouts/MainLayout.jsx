import { Outlet, Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { Sun, Moon, ShoppingBag, Menu, X, User } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import Button from '../components/ui/Button';

export default function MainLayout() {
  const [isDark, setIsDark] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { userInfo } = useSelector((state) => state.auth);
  const cartCount = useSelector((state) => state.cart.items.reduce((total, item) => total + item.quantity, 0));

  useEffect(() => {
    if (isDark) document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
  }, [isDark]);

  return (
    <div className="min-h-screen flex flex-col">
      <nav className="sticky top-0 z-50 glass border-b-0 py-4 px-6 md:px-12 flex items-center justify-between">
        <Link to="/" className="text-2xl font-bold text-gradient flex items-center gap-2">
          <span className="text-3xl">🍕</span> FoodVerse<span className="text-gradient-accent">AI</span>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8 font-medium">
          <Link to="/" className="hover:text-primary transition-colors">Home</Link>
          <Link to="/restaurants" className="hover:text-primary transition-colors">Restaurants</Link>
          <Link to="/offers" className="hover:text-primary transition-colors">Offers</Link>
          
          <div className="flex items-center gap-4 ml-4">
            <button onClick={() => setIsDark(!isDark)} className="p-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 transition">
              {isDark ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            <Link to="/cart" className="relative">
              <Button variant="ghost" size="icon" className="relative">
                <ShoppingBag size={20} />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-primary text-[10px] text-white px-1">
                    {cartCount}
                  </span>
                )}
              </Button>
            </Link>
            
            {userInfo ? (
              <Button variant="outline" className="gap-2">
                <User size={18} /> {userInfo.name.split(' ')[0]}
              </Button>
            ) : (
              <Link to="/login">
                <Button variant="default">Sign In</Button>
              </Link>
            )}
          </div>
        </div>

        {/* Mobile Toggle */}
        <div className="md:hidden flex items-center gap-4">
          <button onClick={() => setIsDark(!isDark)} className="p-2">
            {isDark ? <Sun size={20} /> : <Moon size={20} />}
          </button>
          <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden absolute top-20 left-0 w-full glass flex flex-col p-6 gap-4 z-40"
          >
            <Link to="/" className="text-lg hover:text-primary" onClick={() => setIsMobileMenuOpen(false)}>Home</Link>
            <Link to="/restaurants" className="text-lg hover:text-primary" onClick={() => setIsMobileMenuOpen(false)}>Restaurants</Link>
            <Link to="/offers" className="text-lg hover:text-primary" onClick={() => setIsMobileMenuOpen(false)}>Offers</Link>
            
            <hr className="border-slate-200 dark:border-slate-700 my-2" />
            
            {userInfo ? (
              <Button variant="outline" className="w-full justify-start gap-2">
                <User size={18} /> Profile
              </Button>
            ) : (
              <Link to="/login" onClick={() => setIsMobileMenuOpen(false)}>
                <Button variant="default" className="w-full">Sign In</Button>
              </Link>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      <main className="flex-1">
        <Outlet />
      </main>

      <footer className="glass mt-12 py-8 px-6 text-center">
        <p className="text-slate-500 dark:text-slate-400">© 2026 FoodVerse AI. All rights reserved.</p>
        <p className="text-sm mt-2 font-medium text-gradient-accent">Built with React + Vite + Tailwind</p>
      </footer>
    </div>
  );
}
