import { useState } from 'react';
import { motion } from 'framer-motion';
import { useDispatch } from 'react-redux';
import Button from '../components/ui/Button';
import { addItem } from '../redux/slices/cartSlice';

const restaurantData = [
  {
    id: 1,
    name: 'Neon Noodles',
    cuisine: ['Asian', 'Noodles'],
    rating: 4.9,
    deliveryTime: '20-28 min',
    costForTwo: 22,
    badge: 'Hot',
    image: '🍜',
    category: 'Asian',
  },
  {
    id: 2,
    name: 'Crimson Burger',
    cuisine: ['American', 'Burgers'],
    rating: 4.7,
    deliveryTime: '18-25 min',
    costForTwo: 18,
    badge: 'Popular',
    image: '🍔',
    category: 'Burgers',
  },
  {
    id: 3,
    name: 'Sakura Sushi',
    cuisine: ['Japanese', 'Sushi'],
    rating: 4.8,
    deliveryTime: '25-32 min',
    costForTwo: 30,
    badge: 'Premium',
    image: '🍣',
    category: 'Sushi',
  },
  {
    id: 4,
    name: 'Green Table',
    cuisine: ['Healthy', 'Salads'],
    rating: 4.6,
    deliveryTime: '15-22 min',
    costForTwo: 20,
    badge: 'Fresh',
    image: '🥗',
    category: 'Healthy',
  },
];

const categories = ['All', 'Asian', 'Burgers', 'Sushi', 'Healthy'];

export default function Restaurants() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const dispatch = useDispatch();

  const filteredRestaurants = restaurantData.filter((restaurant) =>
    selectedCategory === 'All' || restaurant.cuisine.includes(selectedCategory),
  );

  return (
    <div className="px-6 md:px-12 py-14">
      <div className="max-w-6xl mx-auto">
        <section className="mb-12">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-8">
            <div>
              <p className="text-sm uppercase tracking-[0.25em] text-primary font-semibold">Restaurant discovery</p>
              <h1 className="text-4xl md:text-5xl font-bold">Find your next favorite spot</h1>
            </div>
            <Button variant="secondary" size="lg">Explore hottest picks</Button>
          </div>

          <div className="flex flex-wrap gap-3">
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                onClick={() => setSelectedCategory(category)}
                className={`rounded-2xl px-4 py-2 transition ${
                  selectedCategory === category
                    ? 'bg-primary text-white shadow-lg shadow-primary/20'
                    : 'border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </section>

        <section className="grid gap-6 lg:grid-cols-2">
          {filteredRestaurants.map((restaurant) => (
            <motion.article
              key={restaurant.id}
              whileHover={{ y: -6 }}
              className="glass rounded-3xl p-6 shadow-xl border border-white/10"
            >
              <div className="flex items-center justify-between gap-4 mb-6">
                <div className="text-5xl">{restaurant.image}</div>
                <span className="rounded-full bg-primary/10 text-primary px-3 py-1 text-sm font-semibold">{restaurant.badge}</span>
              </div>

              <div className="space-y-3">
                <h2 className="text-2xl font-bold">{restaurant.name}</h2>
                <div className="flex flex-wrap gap-2">
                  {restaurant.cuisine.map((tag) => (
                    <span key={tag} className="rounded-full bg-slate-100 px-3 py-1 text-sm text-slate-700 dark:bg-slate-800 dark:text-slate-200">{tag}</span>
                  ))}
                </div>
                <div className="flex flex-wrap items-center gap-4 text-sm text-slate-500 dark:text-slate-400">
                  <span>⭐ {restaurant.rating}</span>
                  <span>{restaurant.deliveryTime}</span>
                  <span>${restaurant.costForTwo} for two</span>
                </div>
                <p className="text-slate-600 dark:text-slate-300">A highly rated kitchen known for fresh ingredients, speedy delivery, and mouthwatering favorites.</p>
              </div>

              <div className="mt-6 flex flex-wrap gap-3">
                <Button variant="glass">View Menu</Button>
                <Button
                  variant="default"
                  onClick={() => dispatch(addItem({ id: restaurant.id, name: restaurant.name, price: restaurant.costForTwo / 2, category: restaurant.category }))}
                >
                  Add to cart
                </Button>
              </div>
            </motion.article>
          ))}
        </section>
      </div>
    </div>
  );
}
