import { useState } from 'react';
import { motion } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { Mail, Lock, User, Briefcase } from 'lucide-react';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import { setCredentials } from '../redux/slices/authSlice';

export default function Signup() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    role: 'user',
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.email || formData.password.length < 6) {
      setError('Name, email, and a password with at least 6 characters are required.');
      return;
    }

    setError('');
    setIsLoading(true);

    setTimeout(() => {
      dispatch(setCredentials({ name: formData.name, email: formData.email, role: formData.role }));
      setIsLoading(false);
      navigate('/');
    }, 900);
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-10">
      <div className="absolute bottom-1/4 right-1/4 w-72 h-72 bg-secondary/20 rounded-full blur-[100px] -z-10" />
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="glass w-full max-w-md p-8 rounded-3xl"
      >
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Create Account</h1>
          <p className="text-slate-500 dark:text-slate-400">Join the future of food delivery with a personalized profile.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <Input 
            label="Full Name"
            type="text"
            placeholder="John Doe"
            icon={User}
            value={formData.name}
            onChange={(e) => setFormData({...formData, name: e.target.value})}
            required
          />
          <Input 
            label="Email Address"
            type="email"
            placeholder="you@example.com"
            icon={Mail}
            value={formData.email}
            onChange={(e) => setFormData({...formData, email: e.target.value})}
            required
          />
          <Input 
            label="Password"
            type="password"
            placeholder="••••••••"
            icon={Lock}
            value={formData.password}
            onChange={(e) => setFormData({...formData, password: e.target.value})}
            required
          />

          <div>
            <label className="mb-2 block text-sm font-medium text-slate-700 dark:text-slate-300">Account Type</label>
            <div className="relative">
               <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none z-10">
                  <Briefcase size={18} />
               </div>
               <select 
                 className="flex h-12 w-full appearance-none rounded-xl border border-slate-200 bg-white pl-10 pr-4 py-2 text-sm ring-offset-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 dark:border-slate-700 dark:bg-slate-900/50 dark:ring-offset-slate-950 transition-all duration-300 cursor-pointer"
                 value={formData.role}
                 onChange={(e) => setFormData({...formData, role: e.target.value})}
               >
                 <option value="user">Hungry User</option>
                 <option value="restaurant_owner">Restaurant Owner</option>
                 <option value="delivery_partner">Delivery Partner</option>
               </select>
            </div>
          </div>

          {error && <p className="text-sm text-red-500">{error}</p>}

          <Button type="submit" className="w-full h-12 text-lg mt-4" isLoading={isLoading}>
            Sign Up
          </Button>
        </form>

        <p className="text-center mt-6 text-slate-600 dark:text-slate-400">
          Already have an account? <Link to="/login" className="text-primary font-medium hover:underline">Sign in</Link>
        </p>
      </motion.div>
    </div>
  );
}
