import { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Search, MapPin, Sparkles, Star, HeartHandshake, Bolt } from 'lucide-react';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';

export default function Home() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const categories = ['All', 'Pizza', 'Burgers', 'Sushi', 'Healthy', 'Desserts'];

  const trendingFoods = [
    { id: 1, name: 'Spicy Ramen', price: '$12', rating: 4.8, img: '🍜', color: 'bg-orange-500/20', category: 'Healthy' },
    { id: 2, name: 'Truffle Burger', price: '$15', rating: 4.9, img: '🍔', color: 'bg-red-500/20', category: 'Burgers' },
    { id: 3, name: 'Sushi Platter', price: '$24', rating: 4.7, img: '🍣', color: 'bg-emerald-500/20', category: 'Sushi' },
    { id: 4, name: 'Berry Bliss Bowl', price: '$11', rating: 4.6, img: '🥣', color: 'bg-fuchsia-500/20', category: 'Healthy' },
    { id: 5, name: 'Chocolate Lava Cake', price: '$9', rating: 4.9, img: '🍰', color: 'bg-pink-500/20', category: 'Desserts' },
  ];

  const recommendedRestaurants = [
    { id: 1, name: 'Sunset Sushi', tag: 'Best for groups', eta: '22 min', rating: 4.9, image: '🍣' },
    { id: 2, name: 'Firefly Burgers', tag: 'Juicy & hot', eta: '18 min', rating: 4.8, image: '🍔' },
    { id: 3, name: 'Green Garden', tag: 'Fresh choices', eta: '15 min', rating: 4.7, image: '🥗' },
  ];

  const filteredFoods = useMemo(() => {
    return trendingFoods.filter((food) => {
      const matchesQuery = food.name.toLowerCase().includes(searchQuery.toLowerCase()) || food.category.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === 'All' || food.category === selectedCategory;
      return matchesQuery && matchesCategory;
    });
  }, [searchQuery, selectedCategory, trendingFoods]);

  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative overflow-hidden px-6 md:px-12 py-20 flex flex-col md:flex-row items-center justify-between min-h-[80vh]">
        <div className="absolute top-0 -left-10 w-96 h-96 bg-primary/20 rounded-full blur-[100px]" />
        <div className="absolute bottom-0 -right-10 w-96 h-96 bg-secondary/20 rounded-full blur-[100px]" />

        <div className="w-full md:w-1/2 z-10 flex flex-col gap-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 glass px-4 py-2 rounded-full w-max text-sm font-medium text-primary"
          >
            <Sparkles size={16} /> AI-Powered Food Delivery
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-5xl md:text-7xl font-bold leading-tight"
          >
            Smarter <span className="text-gradient">Craving,</span> <br />
            Faster <span className="text-gradient">Delivery.</span>
          </motion.h1>

          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-lg text-slate-600 dark:text-slate-400 max-w-md"
          >
            Let FoodVerse AI serve the best local restaurants, fresh offers, and curated recommendations.
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="flex flex-col sm:flex-row gap-4 mt-4 w-full max-w-lg"
          >
            <div className="flex-1">
              <Input 
                placeholder="Search food, restaurants, or cuisine" 
                icon={Search} 
                className="h-14 rounded-2xl"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button className="h-14 rounded-2xl px-8" size="lg">Search</Button>
          </motion.div>

          <div className="grid grid-cols-2 gap-3 max-w-md mt-6">
            <div className="glass rounded-3xl p-4 flex items-center gap-3 shadow-xl">
              <Bolt size={24} className="text-primary" />
              <div>
                <p className="text-sm text-slate-500 dark:text-slate-400">Fastest delivery</p>
                <p className="font-semibold">Under 20 mins</p>
              </div>
            </div>
            <div className="glass rounded-3xl p-4 flex items-center gap-3 shadow-xl">
              <HeartHandshake size={24} className="text-secondary" />
              <div>
                <p className="text-sm text-slate-500 dark:text-slate-400">Trusted partners</p>
                <p className="font-semibold">4.8+ rating</p>
              </div>
            </div>
          </div>
        </div>

        <div className="w-full md:w-1/2 h-[400px] md:h-[600px] relative mt-12 md:mt-0 z-10 flex items-center justify-center">
          <motion.div 
            animate={{ y: [-15, 15, -15] }}
            transition={{ repeat: Infinity, duration: 6, ease: 'easeInOut' }}
            className="absolute top-10 left-10 md:left-20 w-40 h-48 glass rounded-3xl p-4 flex flex-col items-center justify-center gap-2 shadow-2xl z-20"
          >
             <span className="text-6xl">🍕</span>
             <h3 className="font-bold">Hot Pizza</h3>
             <div className="flex text-yellow-400"><Star size={16} fill="currentColor" /> 4.9</div>
          </motion.div>
          
          <motion.div 
            animate={{ y: [15, -15, 15] }}
            transition={{ repeat: Infinity, duration: 5, ease: 'easeInOut' }}
            className="absolute bottom-10 right-10 md:right-20 w-48 h-56 glass rounded-3xl p-4 flex flex-col items-center justify-center gap-2 shadow-2xl z-10 border border-primary/20"
          >
             <span className="text-7xl">🍔</span>
             <h3 className="font-bold">Mega Burger</h3>
             <span className="text-primary font-bold">$15.99</span>
          </motion.div>

          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 1, type: 'spring' }}
            className="w-64 h-64 md:w-80 md:h-80 rounded-full bg-gradient-to-tr from-primary to-secondary animate-pulse-glow flex items-center justify-center"
          >
             <span className="text-white font-bold text-2xl drop-shadow-md">AI Chef</span>
          </motion.div>
        </div>
      </section>

      <section className="px-6 md:px-12 py-16">
        <div className="mb-10">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
            <div>
              <h2 className="text-3xl font-bold">Popular categories</h2>
              <p className="text-slate-600 dark:text-slate-400">Filter trending dishes by your favorite type of food.</p>
            </div>
            <div className="flex flex-wrap gap-3">
              {categories.map((category) => (
                <button
                  key={category}
                  type="button"
                  onClick={() => setSelectedCategory(category)}
                  className={`rounded-full px-4 py-2 text-sm transition ${selectedCategory === category ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'}`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {filteredFoods.map((food) => (
            <motion.div
              key={food.id}
              whileHover={{ y: -6 }}
              className="glass rounded-3xl p-6 overflow-hidden relative"
            >
              <div className={`absolute -right-10 -top-10 w-32 h-32 rounded-full blur-2xl ${food.color}`} />
              <div className="relative z-10">
                <div className="text-6xl mb-4">{food.img}</div>
                <h3 className="text-xl font-bold mb-2">{food.name}</h3>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-lg font-bold text-primary">{food.price}</span>
                  <span className="flex items-center gap-1 text-sm font-medium"><Star size={14} className="text-yellow-400" fill="currentColor" /> {food.rating}</span>
                </div>
                <Button variant="glass">Add to cart</Button>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="px-6 md:px-12 pb-20">
        <div className="mb-10">
          <h2 className="text-3xl font-bold">Recommended restaurants</h2>
          <p className="text-slate-600 dark:text-slate-400">AI selects the best local kitchens for you today.</p>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          {recommendedRestaurants.map((restaurant, i) => (
            <motion.div
              key={restaurant.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="glass rounded-3xl p-6 shadow-xl border border-white/10"
            >
              <div className="text-5xl mb-4">{restaurant.image}</div>
              <h3 className="text-2xl font-bold mb-2">{restaurant.name}</h3>
              <p className="text-slate-600 dark:text-slate-300 mb-4">{restaurant.tag}</p>
              <div className="flex items-center justify-between text-sm text-slate-500 dark:text-slate-400 mb-6">
                <span>{restaurant.eta}</span>
                <span>⭐ {restaurant.rating}</span>
              </div>
              <Button variant="default">View restaurant</Button>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}
