import { motion } from 'framer-motion';
import Button from '../components/ui/Button';

const offers = [
  {
    id: 1,
    title: 'Free Delivery Weekend',
    description: 'No delivery fee on selected restaurants for the next 48 hours.',
    discount: 'Free delivery',
    badge: 'Weekends',
  },
  {
    id: 2,
    title: '30% Off Sushi Sets',
    description: 'Premium sushi combos at a delicious discount.',
    discount: '30% OFF',
    badge: 'Limited',
  },
  {
    id: 3,
    title: 'Buy One, Get One Pizza',
    description: 'Pair any large pizza with a second one on us.',
    discount: 'BOGO',
    badge: 'Special',
  },
];

export default function Offers() {
  return (
    <div className="px-6 md:px-12 py-14">
      <div className="max-w-6xl mx-auto">
        <header className="mb-10">
          <p className="text-sm uppercase tracking-[0.25em] text-primary font-semibold">Exclusive deals</p>
          <h1 className="text-4xl md:text-5xl font-bold mt-3">Save more on every order</h1>
          <p className="mt-4 max-w-2xl text-slate-600 dark:text-slate-400">Stay ahead of the cravings with curated promos, seasonal bundles, and AI-picked offers for your taste.</p>
        </header>

        <section className="grid gap-6 md:grid-cols-3">
          {offers.map((offer, index) => (
            <motion.article
              key={offer.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="glass rounded-3xl p-6 border border-white/10 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm uppercase tracking-[0.25em] text-slate-500 dark:text-slate-400">{offer.badge}</span>
                <span className="rounded-full bg-primary/10 text-primary px-3 py-1 text-sm font-semibold">{offer.discount}</span>
              </div>
              <h2 className="text-2xl font-bold mb-3">{offer.title}</h2>
              <p className="text-slate-600 dark:text-slate-300 mb-6">{offer.description}</p>
              <div className="flex items-center justify-between gap-4">
                <Button variant="secondary">Save Offer</Button>
                <span className="text-sm text-slate-500 dark:text-slate-400">Ends soon</span>
              </div>
            </motion.article>
          ))}
        </section>

        <div className="mt-14 glass rounded-3xl p-8 border border-white/10 shadow-xl">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div>
              <p className="text-sm uppercase tracking-[0.25em] text-primary font-semibold">VIP unlock</p>
              <h2 className="text-3xl font-bold mt-2">Get early access to flash sales</h2>
              <p className="mt-3 text-slate-600 dark:text-slate-400">Join our insider list to receive daily deals, cashback offers, and personalized flavor picks.</p>
            </div>
            <Button variant="default" size="lg">Join the club</Button>
          </div>
        </div>
      </div>
    </div>
  );
}
