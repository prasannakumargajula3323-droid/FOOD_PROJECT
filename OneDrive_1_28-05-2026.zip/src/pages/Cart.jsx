import { useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { motion } from 'framer-motion';
import { Trash2, Minus, Plus } from 'lucide-react';
import Button from '../components/ui/Button';
import { removeItem, updateQuantity, clearCart } from '../redux/slices/cartSlice';

export default function Cart() {
  const dispatch = useDispatch();
  const cartItems = useSelector((state) => state.cart.items);

  const totalPrice = useMemo(() => {
    return cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  }, [cartItems]);

  return (
    <div className="px-6 md:px-12 py-14">
      <div className="max-w-5xl mx-auto">
        <div className="mb-10">
          <p className="text-sm uppercase tracking-[0.25em] text-primary font-semibold">Your bag</p>
          <h1 className="text-4xl md:text-5xl font-bold mt-3">Review your order</h1>
          <p className="mt-3 text-slate-600 dark:text-slate-400">Manage items, update quantities, and checkout with confidence.</p>
        </div>

        {cartItems.length === 0 ? (
          <div className="glass rounded-3xl p-10 text-center">
            <p className="text-xl font-semibold">Your cart is empty.</p>
            <p className="mt-3 text-slate-500 dark:text-slate-400">Add something delicious from the restaurants page.</p>
          </div>
        ) : (
          <div className="grid gap-8 lg:grid-cols-[2fr_1fr]">
            <div className="space-y-4">
              {cartItems.map((item) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="glass rounded-3xl p-6 flex flex-col gap-4"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h2 className="text-xl font-bold">{item.name}</h2>
                      <p className="text-sm text-slate-500 dark:text-slate-400">{item.category}</p>
                    </div>
                    <button
                      type="button"
                      className="text-slate-600 hover:text-red-500 dark:text-slate-300"
                      onClick={() => dispatch(removeItem(item.id))}
                    >
                      <Trash2 size={20} />
                    </button>
                  </div>

                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-2 rounded-full border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2">
                      <button
                        type="button"
                        onClick={() => dispatch(updateQuantity({ id: item.id, quantity: item.quantity - 1 }))}
                        className="text-slate-600 hover:text-primary"
                      >
                        <Minus size={18} />
                      </button>
                      <span className="font-semibold">{item.quantity}</span>
                      <button
                        type="button"
                        onClick={() => dispatch(updateQuantity({ id: item.id, quantity: item.quantity + 1 }))}
                        className="text-slate-600 hover:text-primary"
                      >
                        <Plus size={18} />
                      </button>
                    </div>
                    <p className="text-lg font-semibold">${(item.price * item.quantity).toFixed(2)}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            <aside className="glass rounded-3xl p-6 space-y-6">
              <div>
                <p className="text-sm text-slate-500 dark:text-slate-400">Subtotal</p>
                <p className="text-4xl font-bold mt-2">${totalPrice.toFixed(2)}</p>
              </div>
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm text-slate-500 dark:text-slate-400">
                  <span>Delivery</span>
                  <span>Free</span>
                </div>
                <div className="flex items-center justify-between text-sm text-slate-500 dark:text-slate-400">
                  <span>Taxes</span>
                  <span>Calculated at checkout</span>
                </div>
              </div>
              <Button className="w-full" size="lg">Proceed to checkout</Button>
              <Button variant="ghost" className="w-full" onClick={() => dispatch(clearCart())}>
                Clear cart
              </Button>
            </aside>
          </div>
        )}
      </div>
    </div>
  );
}
